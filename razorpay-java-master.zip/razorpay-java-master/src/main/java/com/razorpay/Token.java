package com.razorpay;

import org.json.JSONObject;

public class Token extends Entity {

  public Token(JSONObject jsonObject) {
    super(jsonObject);
  }
}