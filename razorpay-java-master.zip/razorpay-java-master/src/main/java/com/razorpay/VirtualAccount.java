package com.razorpay;

import org.json.JSONObject;

public class VirtualAccount extends Entity {

  public VirtualAccount(JSONObject jsonObject) {
    super(jsonObject);
  }
}
