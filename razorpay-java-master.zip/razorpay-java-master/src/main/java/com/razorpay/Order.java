package com.razorpay;

import org.json.JSONObject;

public class Order extends Entity {

  public Order(JSONObject jsonObject) {
    super(jsonObject);
  }
}
