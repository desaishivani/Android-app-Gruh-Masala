package com.razorpay;

import org.json.JSONObject;

public class Plan extends Entity {

    public Plan(JSONObject jsonObject) {
        super(jsonObject);
    }
}
