package com.razorpay;

import org.json.JSONObject;

public class Refund extends Entity {

  public Refund(JSONObject jsonObject) {
    super(jsonObject);
  }
}
