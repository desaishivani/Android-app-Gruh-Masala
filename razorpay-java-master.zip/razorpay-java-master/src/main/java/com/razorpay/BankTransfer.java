package com.razorpay;

import org.json.JSONObject;

public class BankTransfer extends Entity {

  public BankTransfer(JSONObject jsonObject) {
    super(jsonObject);
  }
}
